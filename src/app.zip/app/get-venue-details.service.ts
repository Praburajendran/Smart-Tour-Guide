import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpParams } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from "rxjs";

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/first';

@Injectable({
  providedIn: 'root'
})
export class GetVenueDetailsService {

  public venueplaceurl;
  constructor(private httpClient: HttpClient) { }

        getPlaceDetail(venueid){
                this.venueplaceurl = 'https://api.foursquare.com/v2/venues/'+venueid;
                let venueplaceparams = new HttpParams();
                venueplaceparams = venueplaceparams.append('v', '20181230');
                venueplaceparams = venueplaceparams.append('client_id', 'KITSXSTLJTSCKZ3H5HOG5CYR1ILA1VQJR4GWM0ZZ1JWBG14M');
                venueplaceparams = venueplaceparams.append('client_secret', '1JJZU5JKEA4VTBHCRECBQ3X2YZXDZPZJKU1EOEOFNKNU0TTG');

                var venueplacereq = this.httpClient.get(this.venueplaceurl,{params:venueplaceparams});

                return this.httpClient.get(this.venueplaceurl,{params:venueplaceparams});
        }
}
